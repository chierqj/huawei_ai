# coding: utf-8

# 队伍ID
team_id = None
# 队伍名称
team_name = "A+CK.AI"

# 本地日志目录; 提交日志目录（submit时候注意替换）
# log_file_path = 'C:/Users/StrawberryWang/Desktop/huawei_ai/log/battle.log'
log_file_path = '/var/log/battle.log'

# debug模式最短路径也保存，提交的时候不需要
need_short_path = False

# log是否输出详细每条鱼每一步的情况
record_log = True
