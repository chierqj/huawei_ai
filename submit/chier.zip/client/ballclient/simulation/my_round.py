# coding: utf-8
from ballclient.auth import config
from ballclient.simulation.my_leg_start import mLegStart
from ballclient.utils.logger import mLogger
from ballclient.utils.time_wapper import msimulog

from ballclient.simulation.do_beat import mDoBeat
from ballclient.simulation.do_think import mDoThink
from ballclient.simulation.my_player import mPlayers, othPlayers
from ballclient.simulation.my_power import Power


class Round(object):
    def __init__(self):
        self.msg = ""
        self.result = {
            "msg_name": "action",
            "msg_data": {
                "round_id": None,
                "actions": []
            }
        }
        self.POWER_WAIT_SET = dict()

    # 暴露给service使用的，获取最终结果
    def get_result(self):
        return self.result

    # 检查players是否存在，True表示存在
    def check_players(self):
        return "players" in self.msg["msg_data"]

    # 检查teamid是否存在player，True表示存在
    def check_team(self, player):
        return "team" in player

    # 检查power是否存在，True表示存在
    def check_power(self):
        return "power" in self.msg["msg_data"]

    # 检查wormhole是否存在，True表示存在
    def check_wormhole(self):
        return "wormhole" in mLegStart.msg["msg_data"]["map"]

    # 判断边界，True表示在边界内
    def match_border(self, x, y):
        if x < 0 or x >= mLegStart.msg['msg_data']['map']['width']:
            return False
        if y < 0 or y >= mLegStart.msg['msg_data']['map']['height']:
            return False
        return True

    # 判断是否为陨石，True表示为陨石，不能走
    def match_meteor(self, px, py):
        if mLegStart.get_graph_cell(px, py) == '#':
            return True
        return False

    # 根据move改变坐标
    def go_next(self, x, y, move):
        if move == 'up':
            return x, y - 1
        if move == 'down':
            return x, y + 1
        if move == 'left':
            return x - 1, y
        if move == 'right':
            return x + 1, y

    # x, y这个点在向move这方向移动后，真正的坐标是哪里，有虫洞或者传送带
    def real_go_point(self, x, y, move):
        go_x, go_y = self.go_next(x, y, move)
        if False == self.match_border(go_x, go_y):
            return None, None
        if True == self.match_meteor(go_x, go_y):
            return None, None
        go_cell = mLegStart.get_graph_cell(go_x, go_y)
        if mLegStart.match_tunnel(go_cell):
            go_cell_id = mLegStart.get_cell_id(go_x, go_y)
            go_x, go_y = mLegStart.get_x_y(mLegStart.do_tunnel(go_cell_id))
        if mLegStart.match_wormhole(go_cell):
            go_x, go_y = mLegStart.get_x_y(mLegStart.do_wormhoe(go_cell))
        return go_x, go_y

    # 获取action准备动作，先对所有鱼求最短路。然后根据模式不同执行不同的策略。
    def make_action(self):
        # 检查用的变量是否存在
        self.result["msg_data"]["round_id"] = self.msg['msg_data'].get(
            'round_id', None)

        # 调用函数获取action
        action = []
        if self.msg['msg_data']['mode'] == "beat":
            action = mDoBeat.excute(self)
        else:
            action = mDoBeat.excute(self)
            # action = mDoThink.excute(self)

        self.result['msg_data']['actions'] = action

    # 初始化赋值msg消息;更新fish和power集合
    def initialize_msg(self, msg):
        self.msg = msg

    # 更新players状态
    def initialize_players(self):
        for k, value in mPlayers.iteritems():
            value.initialize()
            value.update_last_appear()
        for k, value in othPlayers.iteritems():
            value.initialize()
            value.update_last_appear()

    def update_player_wait_set(self):
        if False == self.check_players():
            return
        players = self.msg['msg_data'].get('players', [])
        for player in players:
            if player.get("team", -1) == config.team_id:
                mPlayers[player['id']].assign(
                    last_appear_dis=0,
                    score=player['score'],
                    sleep=(False if player['sleep'] == 0 else True),
                    x=player['x'],
                    y=player['y'],
                    visiable=True
                )
            else:
                othPlayers[player['id']].assign(
                    last_appear_dis=0,
                    score=player['score'],
                    sleep=(False if player['sleep'] == 0 else True),
                    x=player['x'],
                    y=player['y'],
                    visiable=True
                )

    def update_power_wait_set(self):
        if False == self.check_power():
            return
        for k, v in self.POWER_WAIT_SET.iteritems():
            v.update_last_appear()
        for power in self.msg['msg_data']['power']:
            cell_id = mLegStart.get_cell_id(power['x'], power['y'])
            if cell_id in self.POWER_WAIT_SET:
                self.POWER_WAIT_SET[cell_id].assign(
                    last_appear_dis=0,
                    x=power['x'],
                    y=power['y'],
                    point=power['point'],
                    visiable=True
                )
            else:
                self.POWER_WAIT_SET[cell_id] = Power(
                    last_appear_dis=0,
                    x=power['x'],
                    y=power['y'],
                    point=power['point'],
                    visiable=True
                )

    def update_cell_vis_cnt(self):
        for k, player in mPlayers.iteritems():
            if player.sleep == False:
                cell_id = mLegStart.get_cell_id(player.x, player.y)
                num = mLegStart.cell_vis_cnt.get(cell_id, 0)
                mLegStart.cell_vis_cnt[cell_id] = num + 1
            else:
                mLogger.warning("[fish: {}; point: ({}, {})] 睡眠了，被吃了".format(
                    player.id, player.x, player.y))

    def print_log(self):
        round_id = self.msg['msg_data']['round_id']
        mLogger.info(
            "\n\n-------------------------[round: {}]-------------------------\n".format(round_id))

    # 程序入口
    def excute(self, msg):
        self.initialize_msg(msg)
        self.print_log()
        self.initialize_players()
        self.update_player_wait_set()
        self.update_power_wait_set()
        self.update_cell_vis_cnt()
        self.make_action()


mRound = Round()
