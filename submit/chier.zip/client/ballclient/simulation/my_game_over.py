# coding: utf-8

from ballclient.simulation.my_leg_end import mLegEnd
from ballclient.auth import config


class GameOver(object):
    def __init__(self):
        self.msg = ""

    def initialize_msg(self, msg):
        self.msg = msg

    def excute(self, msg):
        self.initialize_msg(msg)
        for key, point in mLegEnd.tolPoint.iteritems():
            team = "My" if key == str(config.team_id) else "Oth"
            print("[Team: {}, First: {}, Second: {}, Total: {}]".format(
                team, point[0], point[1], point[0] + point[1]))

        print("")
        tol_eated_count, tol_eated_score = 0, 0
        for k, v in mLegEnd.eated_info.iteritems():
            print("[player: {}, tol_sleep: {}, eated: {}, sleep_lost_score: {}, lost_score: {}]".format(
                k, v['count'], v['count'] / 3, v['score'], v['score'] / 3
            ))
            tol_eated_count += v['count'] / 3
            tol_eated_score += v['score'] / 3
        print("[tol_eated: {}, tol_lost_score: {}]".format(tol_eated_count, tol_eated_score))
        mLegEnd.tolPoint.clear()
        mLegEnd.eated_info.clear()


mGameOver = GameOver()
